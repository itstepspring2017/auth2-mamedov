CREATE TRIGGER likes_BEFORE_DELETE
  BEFORE DELETE
  ON likes
  FOR EACH ROW
  BEGIN
	UPDATE `posts` SET `likes`=`likes`-1 WHERE `id`= OLD.posts_id;
END;

