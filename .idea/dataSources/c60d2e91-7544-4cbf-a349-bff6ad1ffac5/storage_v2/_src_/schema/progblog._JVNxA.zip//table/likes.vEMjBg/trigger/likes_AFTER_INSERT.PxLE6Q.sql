CREATE TRIGGER likes_AFTER_INSERT
  AFTER INSERT
  ON likes
  FOR EACH ROW
  BEGIN
	UPDATE `posts` SET `likes`=`likes`+1 WHERE `id`= NEW.posts_id;
END;

